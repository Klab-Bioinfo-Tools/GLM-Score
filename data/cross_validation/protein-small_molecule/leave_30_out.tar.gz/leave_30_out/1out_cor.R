predicted <- read.table("predicted.txt")
experimental <- read.table("experimental.txt")
write.table(cor(predicted, experimental), file="cross_validation_correlation_result.txt", quote=FALSE, row.names = FALSE, col.names = FALSE, sep="\t")   